# Overview

This is a retro pixel-art browser game called "Class Time Hacker" built as a full-stack web application. The game simulates a stealth-based classroom experience where players control a student character who must perform various actions while avoiding detection by the teacher. The application features a React frontend with TypeScript, an Express.js backend, and uses shadcn/ui components for the user interface with a retro gaming aesthetic.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The client-side application is built with React 18 and TypeScript, using Vite as the build tool and development server. The application follows a component-based architecture with custom hooks for game state management. Key architectural decisions include:

- **Component Structure**: Separation of game logic into dedicated components (GameCanvas, GameUI, MobileControls) for maintainability
- **Custom Hooks**: Game state is managed through a centralized `useGameState` hook that handles all game mechanics, player actions, and game loop updates
- **Canvas Rendering**: Uses HTML5 Canvas for pixel-perfect game graphics with custom sprite rendering functions
- **Mobile Support**: Responsive design with touch controls for mobile devices using a virtual D-pad interface
- **Routing**: Simple client-side routing with wouter for lightweight navigation

## Styling and UI Framework
The application uses Tailwind CSS for styling with shadcn/ui components providing a consistent design system. A custom retro gaming theme is implemented with:

- **Pixel Font**: "Press Start 2P" font for authentic retro gaming feel
- **Color Scheme**: Neon green (#00ff88) and purple gradient backgrounds for cyberpunk aesthetic
- **CSS Variables**: Extensive use of CSS custom properties for theme customization
- **Component Library**: Full shadcn/ui component suite for consistent UI elements

## Backend Architecture
The server is built with Express.js and follows a modular architecture:

- **Route Registration**: Centralized route handling through a `registerRoutes` function
- **Storage Abstraction**: Interface-based storage system with in-memory implementation for development
- **Middleware**: Request logging and error handling middleware for debugging and monitoring
- **Development Integration**: Vite development server integration for hot module replacement

## Game Logic Architecture
The game implements a sophisticated real-time game loop with:

- **State Management**: Comprehensive game state including player position, teacher AI, background NPCs, and game mechanics
- **Entity System**: Separate entity types (Student, Teacher, BackgroundStudent) with individual update cycles
- **Action System**: Cooldown-based action system for game balance
- **Physics**: Collision detection and boundary checking for game world interaction
- **AI Behavior**: Teacher AI with patrol patterns, emotion states, and detection mechanics

# External Dependencies

## Database and ORM
- **Drizzle ORM**: Type-safe SQL query builder configured for PostgreSQL
- **Neon Database**: Serverless PostgreSQL database provider (via @neondatabase/serverless)
- **Database Schema**: User authentication system with username/password storage

## UI and Styling
- **Radix UI**: Comprehensive set of unstyled, accessible UI primitives (@radix-ui/react-*)
- **Tailwind CSS**: Utility-first CSS framework for rapid styling
- **shadcn/ui**: Pre-built component library built on Radix UI and Tailwind
- **Lucide React**: Icon library for consistent iconography

## Development and Build Tools
- **Vite**: Fast build tool and development server with React plugin
- **TypeScript**: Static type checking for improved developer experience
- **PostCSS**: CSS processing with Tailwind CSS integration
- **ESBuild**: Fast JavaScript bundler for production builds

## State Management and Data Fetching
- **TanStack Query**: Server state management for API calls and caching
- **React Hook Form**: Form handling with validation (@hookform/resolvers)
- **Wouter**: Lightweight client-side routing library

## Game Development
- **Canvas API**: Native HTML5 Canvas for game rendering
- **Custom Animation System**: Frame-based animation system for sprite rendering
- **Embla Carousel**: Touch-friendly carousel component for UI elements

## Development Features
- **Replit Integration**: Development banner and error overlay for Replit environment
- **Hot Module Replacement**: Vite-powered HMR for rapid development iteration
- **TypeScript Path Mapping**: Custom import aliases for cleaner code organization

The application is designed as a complete game development stack with modern web technologies, providing both an engaging gaming experience and a robust development environment.