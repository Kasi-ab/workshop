import type { Student, Teacher, Particle, FloatingText, GameState } from '@/hooks/useGameState';

export function updateStudent(
  student: Student, 
  keys: Record<string, boolean>, 
  canvasWidth: number, 
  canvasHeight: number
): Student {
  const updated = { ...student };
  const speed = updated.speed;
  let moved = false;
  
  if (keys['ArrowUp'] || keys['w']) {
    updated.y -= speed;
    moved = true;
  }
  if (keys['ArrowDown'] || keys['s']) {
    updated.y += speed;
    moved = true;
  }
  if (keys['ArrowLeft'] || keys['a']) {
    updated.x -= speed;
    updated.direction = 'left';
    moved = true;
  }
  if (keys['ArrowRight'] || keys['d']) {
    updated.x += speed;
    updated.direction = 'right';
    moved = true;
  }
  
  // Boundary collision
  updated.x = Math.max(0, Math.min(canvasWidth - updated.width, updated.x));
  updated.y = Math.max(0, Math.min(canvasHeight - updated.height, updated.y));
  
  // Stealth mechanic
  updated.isHiding = keys['Shift'] || false;
  updated.speed = updated.isHiding ? 1 : 2;
  
  // Check if hiding behind desk
  for (let i = 0; i < 6; i++) {
    const deskX = 150 + (i % 3) * 120;
    const deskY = 250 + Math.floor(i / 3) * 100;
    if (updated.x > deskX && updated.x < deskX + 80 && 
        updated.y > deskY && updated.y < deskY + 60) {
      updated.isHiding = true;
      break;
    }
  }
  
  if (moved) {
    updated.frame += 0.2;
  }
  
  return updated;
}

export function updateTeacher(
  teacher: Teacher, 
  student: Student, 
  currentDifficulty: number, 
  confusionMeter: number,
  setStealthMeter: (fn: (prev: number) => number) => void,
  setFloatingTexts: (fn: (prev: FloatingText[]) => FloatingText[]) => void
): Teacher {
  const updated = { ...teacher };
  
  // Set difficulty-based properties
  const difficulties = [
    { speed: 1, detectionDelay: 3, patrolSpeed: 20 },
    { speed: 1.5, detectionDelay: 1, patrolSpeed: 15 },
    { speed: 2, detectionDelay: 0.5, patrolSpeed: 10 },
    { speed: 2.5, detectionDelay: 0, patrolSpeed: 8 }
  ];
  
  const diff = difficulties[currentDifficulty];
  updated.speed = diff.speed;
  
  // Update patrol
  const target = updated.patrolPoints[updated.currentTarget];
  const dx = target.x - updated.x;
  const dy = target.y - updated.y;
  const distance = Math.sqrt(dx * dx + dy * dy);
  
  if (distance < 10) {
    updated.currentTarget = (updated.currentTarget + 1) % updated.patrolPoints.length;
  } else {
    updated.x += (dx / distance) * updated.speed;
    updated.y += (dy / distance) * updated.speed;
    updated.direction = dx > 0 ? 'right' : 'left';
  }
  
  // Check detection
  const studentDist = Math.sqrt((student.x - updated.x) ** 2 + (student.y - updated.y) ** 2);
  const inRange = studentDist < updated.detectionRange;
  const facingStudent = (updated.direction === 'right' && student.x > updated.x) || 
                       (updated.direction === 'left' && student.x < updated.x);
  
  if (inRange && facingStudent && !student.isHiding) {
    updated.suspicion += 2;
    if (updated.suspicion > 60) {
      setStealthMeter(prev => Math.max(0, prev - 10));
      updated.suspicion = 0;
      updated.emotion = 'angry';
      setFloatingTexts(prev => [...prev, {
        text: 'CAUGHT!',
        x: updated.x,
        y: updated.y - 20,
        color: '#FF0000',
        life: 2
      }]);
    }
  } else {
    updated.suspicion = Math.max(0, updated.suspicion - 1);
  }
  
  // Update emotion based on confusion meter
  if (updated.freakoutTimer > 0) {
    updated.freakoutTimer--;
    updated.emotion = 'freakout';
  } else if (confusionMeter > 70) {
    updated.emotion = 'confused';
    if (Math.random() < 0.02) {
      updated.freakoutTimer = 120;
      setFloatingTexts(prev => [...prev, {
        text: 'WHAT IS HAPPENING?!',
        x: updated.x,
        y: updated.y - 20,
        color: '#FF6600',
        life: 2
      }]);
    }
  } else if (updated.suspicion > 30) {
    updated.emotion = 'angry';
  } else {
    updated.emotion = 'normal';
  }
  
  updated.frame += 0.1;
  
  return updated;
}

export function updateParticles(particles: Particle[], deltaTime: number): Particle[] {
  return particles.filter(particle => {
    particle.x += particle.vx * deltaTime / 16;
    particle.y += particle.vy * deltaTime / 16;
    particle.life -= deltaTime / 1000;
    return particle.life > 0;
  });
}

export function updateFloatingTexts(floatingTexts: FloatingText[], deltaTime: number): FloatingText[] {
  return floatingTexts.filter(text => {
    text.y -= 30 * deltaTime / 1000;
    text.life -= deltaTime / 1000;
    return text.life > 0;
  });
}

export function checkGameConditions(
  confusionMeter: number, 
  stealthMeter: number, 
  gameTime: number, 
  maxGameTime: number
): GameState | null {
  if (confusionMeter >= 100) {
    return 'victory';
  } else if (stealthMeter <= 0) {
    return 'gameover';
  } else if (gameTime >= maxGameTime) {
    return 'gameover';
  }
  return null;
}

export function executeAction(
  actionType: string, 
  student: Student, 
  canvasWidth: number, 
  canvasHeight: number
): boolean {
  switch(actionType) {
    case 'clock':
      return Math.abs(student.x - 650) < 50 && Math.abs(student.y - 120) < 50;
      
    case 'chalk':
      return Math.abs(student.x - 200) < 80 && Math.abs(student.y - 125) < 80;
      
    case 'bell':
      return Math.abs(student.x - 430) < 50 && Math.abs(student.y - 60) < 50;
      
    case 'paper':
      // Can be used from any desk
      for (let i = 0; i < 6; i++) {
        const deskX = 150 + (i % 3) * 120;
        const deskY = 250 + Math.floor(i / 3) * 100;
        if (Math.abs(student.x - (deskX + 40)) < 60 && 
            Math.abs(student.y - (deskY + 30)) < 60) {
          return true;
        }
      }
      return false;
      
    default:
      return false;
  }
}

export function addParticles(x: number, y: number, type: string): Particle[] {
  const colors: Record<string, string> = {
    clock: '#FFD700',
    chalk: '#FFFFFF',
    bell: '#FFA500',
    paper: '#FFFFFF'
  };
  
  const particles: Particle[] = [];
  for (let i = 0; i < 8; i++) {
    particles.push({
      x: x + Math.random() * 10 - 5,
      y: y + Math.random() * 10 - 5,
      vx: Math.random() * 4 - 2,
      vy: Math.random() * 4 - 2,
      life: 1,
      type: type,
      color: colors[type] || '#FFFFFF',
      size: 2
    });
  }
  
  return particles;
}

export function addFloatingText(text: string, x: number, y: number, color: string): FloatingText {
  return {
    text,
    x,
    y,
    color,
    life: 2
  };
}
