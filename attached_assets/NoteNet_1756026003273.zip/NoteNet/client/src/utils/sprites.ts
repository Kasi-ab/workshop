export function drawStudent(
  ctx: CanvasRenderingContext2D, 
  x: number, 
  y: number, 
  frame: number, 
  direction: 'left' | 'right', 
  isHiding = false
) {
  ctx.save();
  
  if (direction === 'left') {
    ctx.scale(-1, 1);
    x = -x - 32;
  }
  
  // Adjust posture if hiding/sneaking
  const crouchOffset = isHiding ? 4 : 0;
  y += crouchOffset;
  
  // Head (skin tone)
  ctx.fillStyle = '#FFDBAC';
  ctx.fillRect(x + 8, y + 4, 16, 12);
  
  // Hair (brown)
  ctx.fillStyle = '#8B4513';
  ctx.fillRect(x + 6, y + 2, 20, 8);
  ctx.fillRect(x + 4, y + 4, 4, 6); // side hair
  ctx.fillRect(x + 24, y + 4, 4, 6);
  
  // Eyes
  ctx.fillStyle = '#000';
  ctx.fillRect(x + 11, y + 7, 2, 2);
  ctx.fillRect(x + 19, y + 7, 2, 2);
  
  // Mouth (small line)
  ctx.fillRect(x + 15, y + 11, 2, 1);
  
  // School uniform shirt (blue)
  ctx.fillStyle = '#4169E1';
  ctx.fillRect(x + 6, y + 16, 20, 12);
  
  // Collar
  ctx.fillStyle = '#FFF';
  ctx.fillRect(x + 14, y + 16, 4, 6);
  
  // Arms (animated)
  ctx.fillStyle = '#FFDBAC';
  const armOffset = Math.sin(frame * 0.3) * 2;
  ctx.fillRect(x + 2, y + 18 + armOffset, 6, 8);
  ctx.fillRect(x + 24, y + 18 - armOffset, 6, 8);
  
  // Backpack
  ctx.fillStyle = '#228B22';
  ctx.fillRect(x + 26, y + 14, 8, 12);
  
  // Pants (dark blue)
  ctx.fillStyle = '#191970';
  ctx.fillRect(x + 8, y + 28, 16, 4);
  
  // Legs (walking animation)
  const legOffset = Math.sin(frame * 0.4) * 3;
  ctx.fillRect(x + 8, y + 32, 6, 8 + legOffset);
  ctx.fillRect(x + 18, y + 32, 6, 8 - legOffset);
  
  // Shoes
  ctx.fillStyle = '#000';
  ctx.fillRect(x + 6, y + 38 + legOffset, 8, 4);
  ctx.fillRect(x + 18, y + 38 - legOffset, 8, 4);
  
  ctx.restore();
}

export function drawTeacher(
  ctx: CanvasRenderingContext2D, 
  x: number, 
  y: number, 
  frame: number, 
  emotion: 'normal' | 'confused' | 'angry' | 'freakout', 
  direction: 'left' | 'right' = 'right'
) {
  ctx.save();
  
  if (direction === 'left') {
    ctx.scale(-1, 1);
    x = -x - 32;
  }
  
  // Emotion-based modifications
  let eyeStyle = '#000';
  let mouthStyle = 1;
  let shakeOffset = 0;
  
  switch(emotion) {
    case 'confused':
      eyeStyle = '#4169E1';
      shakeOffset = Math.sin(frame * 0.8) * 2;
      break;
    case 'angry':
      eyeStyle = '#FF0000';
      mouthStyle = 3;
      break;
    case 'freakout':
      eyeStyle = '#FF0000';
      mouthStyle = 4;
      shakeOffset = Math.sin(frame * 2) * 4;
      break;
  }
  
  x += shakeOffset;
  
  // Head (skin tone)
  ctx.fillStyle = '#FFDBAC';
  ctx.fillRect(x + 8, y + 2, 16, 14);
  
  // Hair (gray/brown)
  ctx.fillStyle = '#696969';
  ctx.fillRect(x + 6, y + 1, 20, 6);
  
  // Glasses
  ctx.fillStyle = '#000';
  ctx.fillRect(x + 9, y + 6, 6, 4);
  ctx.fillRect(x + 17, y + 6, 6, 4);
  ctx.fillRect(x + 15, y + 7, 2, 1); // bridge
  
  // Eyes behind glasses
  ctx.fillStyle = eyeStyle;
  ctx.fillRect(x + 11, y + 7, 2, 2);
  ctx.fillRect(x + 19, y + 7, 2, 2);
  
  // Mouth (varies by emotion)
  ctx.fillStyle = '#000';
  if (mouthStyle === 1) {
    ctx.fillRect(x + 15, y + 12, 2, 1);
  } else if (mouthStyle === 3) {
    ctx.fillRect(x + 13, y + 12, 6, 2);
  } else if (mouthStyle === 4) {
    ctx.fillRect(x + 12, y + 12, 8, 3);
  }
  
  // Professional blazer
  ctx.fillStyle = '#2F4F4F';
  ctx.fillRect(x + 4, y + 16, 24, 14);
  
  // Shirt and tie
  ctx.fillStyle = '#FFF';
  ctx.fillRect(x + 12, y + 16, 8, 10);
  ctx.fillStyle = '#8B0000';
  ctx.fillRect(x + 14, y + 18, 4, 8);
  
  // Arms
  ctx.fillStyle = '#FFDBAC';
  if (emotion === 'angry') {
    // Hands on hips
    ctx.fillRect(x + 0, y + 20, 6, 6);
    ctx.fillRect(x + 26, y + 20, 6, 6);
  } else {
    // Normal arms
    ctx.fillRect(x + 0, y + 18, 6, 10);
    ctx.fillRect(x + 26, y + 18, 6, 10);
  }
  
  // Pants
  ctx.fillStyle = '#2F4F4F';
  ctx.fillRect(x + 6, y + 30, 20, 10);
  
  // Legs
  ctx.fillStyle = '#FFDBAC';
  ctx.fillRect(x + 8, y + 40, 6, 8);
  ctx.fillRect(x + 18, y + 40, 6, 8);
  
  // Dress shoes
  ctx.fillStyle = '#000';
  ctx.fillRect(x + 6, y + 46, 8, 4);
  ctx.fillRect(x + 18, y + 46, 8, 4);
  
  ctx.restore();
}

export function drawBackgroundStudent(
  ctx: CanvasRenderingContext2D, 
  x: number, 
  y: number, 
  type: 'sleepy' | 'studious' | 'clown' | 'timetravel' | 'narrator', 
  frame: number
) {
  switch(type) {
    case 'sleepy':
      // Head on desk
      ctx.fillStyle = '#FFDBAC';
      ctx.fillRect(x, y + 10, 16, 10);
      ctx.fillStyle = '#8B4513';
      ctx.fillRect(x - 2, y + 8, 20, 6);
      break;
      
    case 'studious':
      // Reading posture
      ctx.fillStyle = '#FFDBAC';
      ctx.fillRect(x + 4, y, 16, 12);
      ctx.fillStyle = '#8B4513';
      ctx.fillRect(x + 2, y - 2, 20, 6);
      ctx.fillStyle = '#4169E1';
      ctx.fillRect(x, y + 12, 24, 12);
      // Book
      ctx.fillStyle = '#8B0000';
      ctx.fillRect(x + 6, y + 20, 12, 8);
      break;
      
    case 'clown':
      // Mischievous grin
      ctx.fillStyle = '#FFDBAC';
      ctx.fillRect(x + 4, y, 16, 12);
      ctx.fillStyle = '#FF4500';
      ctx.fillRect(x + 2, y - 2, 20, 6);
      ctx.fillStyle = '#32CD32';
      ctx.fillRect(x, y + 12, 24, 12);
      break;
      
    case 'timetravel':
      // Outfit changes during glitches
      const colors = ['#4169E1', '#FF6347', '#32CD32', '#9932CC'];
      const colorIndex = Math.floor(frame / 30) % colors.length;
      ctx.fillStyle = '#FFDBAC';
      ctx.fillRect(x + 4, y, 16, 12);
      ctx.fillStyle = '#8B4513';
      ctx.fillRect(x + 2, y - 2, 20, 6);
      ctx.fillStyle = colors[colorIndex];
      ctx.fillRect(x, y + 12, 24, 12);
      break;
      
    case 'narrator':
      // Mouth open like commenting
      ctx.fillStyle = '#FFDBAC';
      ctx.fillRect(x + 4, y, 16, 12);
      ctx.fillStyle = '#8B4513';
      ctx.fillRect(x + 2, y - 2, 20, 6);
      ctx.fillStyle = '#4169E1';
      ctx.fillRect(x, y + 12, 24, 12);
      // Open mouth
      ctx.fillStyle = '#000';
      ctx.fillRect(x + 10, y + 8, 4, 3);
      break;
  }
}
