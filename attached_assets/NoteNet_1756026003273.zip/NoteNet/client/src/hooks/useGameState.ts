import { useState, useRef, useCallback, useEffect } from 'react';
import { 
  updateStudent, 
  updateTeacher, 
  updateParticles, 
  updateFloatingTexts, 
  checkGameConditions,
  executeAction,
  addParticles,
  addFloatingText 
} from '@/utils/gameLogic';

export interface GameAction {
  cooldown: number;
  maxCooldown: number;
  risk: number;
  confusion: number;
}

export interface Student {
  x: number;
  y: number;
  width: number;
  height: number;
  frame: number;
  direction: 'left' | 'right';
  isHiding: boolean;
  speed: number;
}

export interface Teacher {
  x: number;
  y: number;
  width: number;
  height: number;
  frame: number;
  direction: 'left' | 'right';
  emotion: 'normal' | 'confused' | 'angry' | 'freakout';
  patrolPoints: { x: number; y: number }[];
  currentTarget: number;
  speed: number;
  suspicion: number;
  detectionRange: number;
  freakoutTimer: number;
}

export interface BackgroundStudent {
  x: number;
  y: number;
  type: 'sleepy' | 'studious' | 'clown' | 'timetravel' | 'narrator';
  frame: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  type: string;
  color?: string;
  size?: number;
}

export interface FloatingText {
  text: string;
  x: number;
  y: number;
  color: string;
  life: number;
}

export type GameState = 'title' | 'playing' | 'gameover' | 'victory';

export function useGameState() {
  const [gameState, setGameState] = useState<GameState>('title');
  const [currentDifficulty, setCurrentDifficulty] = useState(0);
  const [gameTime, setGameTime] = useState(0);
  const [maxGameTime, setMaxGameTime] = useState(120);
  const [confusionMeter, setConfusionMeter] = useState(0);
  const [stealthMeter, setStealthMeter] = useState(100);
  const [animFrame, setAnimFrame] = useState(0);
  
  const [keys, setKeys] = useState<Record<string, boolean>>({});
  const lastTimeRef = useRef<number>(0);
  
  const [gameActions, setGameActions] = useState<Record<string, GameAction>>({
    clock: { cooldown: 0, maxCooldown: 60, risk: 30, confusion: 25 },
    chalk: { cooldown: 0, maxCooldown: 30, risk: 15, confusion: 12 },
    bell: { cooldown: 0, maxCooldown: 90, risk: 10, confusion: 20 },
    paper: { cooldown: 0, maxCooldown: 15, risk: 8, confusion: 8 }
  });

  const [student, setStudent] = useState<Student>({
    x: 100, y: 300, width: 32, height: 32,
    frame: 0, direction: 'right', isHiding: false,
    speed: 2
  });

  const [teacher, setTeacher] = useState<Teacher>({
    x: 400, y: 200, width: 32, height: 32,
    frame: 0, direction: 'left', emotion: 'normal',
    patrolPoints: [{x: 300, y: 200}, {x: 600, y: 200}, {x: 600, y: 400}, {x: 300, y: 400}],
    currentTarget: 0, speed: 1, suspicion: 0,
    detectionRange: 80, freakoutTimer: 0
  });

  const [backgroundStudents] = useState<BackgroundStudent[]>([
    { x: 200, y: 250, type: 'sleepy', frame: 0 },
    { x: 350, y: 180, type: 'studious', frame: 0 },
    { x: 500, y: 320, type: 'clown', frame: 0 },
    { x: 150, y: 400, type: 'timetravel', frame: 0 },
    { x: 450, y: 450, type: 'narrator', frame: 0 }
  ]);

  const [particles, setParticles] = useState<Particle[]>([]);
  const [floatingTexts, setFloatingTexts] = useState<FloatingText[]>([]);

  const gameLoop = useCallback((currentTime: number) => {
    const deltaTime = currentTime - lastTimeRef.current;
    lastTimeRef.current = currentTime;
    setAnimFrame(prev => prev + 1);

    if (gameState === 'playing') {
      // Update game timer
      setGameTime(prev => prev + deltaTime / 1000);
      
      // Update action cooldowns
      setGameActions(prev => {
        const updated = { ...prev };
        Object.keys(updated).forEach(action => {
          if (updated[action].cooldown > 0) {
            updated[action].cooldown -= deltaTime / 1000;
          }
        });
        return updated;
      });

      // Update entities
      setStudent(prev => updateStudent(prev, keys, 800, 600));
      setTeacher(prev => updateTeacher(prev, student, currentDifficulty, confusionMeter, setStealthMeter, setFloatingTexts));
      setParticles(prev => updateParticles(prev, deltaTime));
      setFloatingTexts(prev => updateFloatingTexts(prev, deltaTime));
      
      // Check game conditions
      const gameCondition = checkGameConditions(confusionMeter, stealthMeter, gameTime, maxGameTime);
      if (gameCondition) {
        setGameState(gameCondition);
      }
    }

    requestAnimationFrame(gameLoop);
  }, [gameState, keys, student, currentDifficulty, confusionMeter, stealthMeter, gameTime, maxGameTime]);

  useEffect(() => {
    const animationId = requestAnimationFrame(gameLoop);
    return () => cancelAnimationFrame(animationId);
  }, [gameLoop]);

  const startGame = useCallback(() => {
    setGameState('playing');
    setGameTime(0);
    setConfusionMeter(0);
    setStealthMeter(100);
    setStudent({
      x: 100, y: 300, width: 32, height: 32,
      frame: 0, direction: 'right', isHiding: false,
      speed: 2
    });
    setTeacher({
      x: 400, y: 200, width: 32, height: 32,
      frame: 0, direction: 'left', emotion: 'normal',
      patrolPoints: [{x: 300, y: 200}, {x: 600, y: 200}, {x: 600, y: 400}, {x: 300, y: 400}],
      currentTarget: 0, speed: 1, suspicion: 0,
      detectionRange: 80, freakoutTimer: 0
    });
    setParticles([]);
    setFloatingTexts([]);
    setGameActions({
      clock: { cooldown: 0, maxCooldown: 60, risk: 30, confusion: 25 },
      chalk: { cooldown: 0, maxCooldown: 30, risk: 15, confusion: 12 },
      bell: { cooldown: 0, maxCooldown: 90, risk: 10, confusion: 20 },
      paper: { cooldown: 0, maxCooldown: 15, risk: 8, confusion: 8 }
    });
  }, []);

  const nextLevel = useCallback(() => {
    if (gameState === 'victory' && currentDifficulty < 3) {
      setCurrentDifficulty(prev => prev + 1);
      setMaxGameTime(prev => prev - 10);
      setTeacher(prev => ({
        ...prev,
        speed: prev.speed + 0.5,
        detectionRange: prev.detectionRange + 10
      }));
    }
    
    if (currentDifficulty >= 3 && gameState === 'victory') {
      setGameState('title');
      setCurrentDifficulty(0);
      setMaxGameTime(120);
    } else {
      startGame();
    }
  }, [gameState, currentDifficulty, startGame]);

  const performAction = useCallback((actionType: string) => {
    const action = gameActions[actionType];
    if (action.cooldown > 0) return;
    
    const success = executeAction(actionType, student, 800, 600);
    
    if (success) {
      setGameActions(prev => ({
        ...prev,
        [actionType]: { ...prev[actionType], cooldown: action.maxCooldown }
      }));
      
      setConfusionMeter(prev => Math.min(100, prev + action.confusion));
      
      if (Math.random() * 100 < action.risk && !student.isHiding) {
        setStealthMeter(prev => Math.max(0, prev - 10));
        setFloatingTexts(prev => [...prev, {
          text: 'NOTICED!',
          x: student.x,
          y: student.y - 20,
          color: '#FF0000',
          life: 2
        }]);
      } else {
        setFloatingTexts(prev => [...prev, {
          text: '+' + action.confusion,
          x: student.x,
          y: student.y - 20,
          color: '#00FF00',
          life: 2
        }]);
      }
      
      setParticles(prev => [
        ...prev,
        ...addParticles(student.x + 16, student.y + 16, actionType)
      ]);
    }
  }, [gameActions, student]);

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    setKeys(prev => ({ ...prev, [e.key]: true }));
    
    if (gameState === 'title' && e.key === ' ') {
      startGame();
    } else if (gameState === 'playing') {
      switch(e.key) {
        case '1': performAction('clock'); break;
        case '2': performAction('chalk'); break;
        case '3': performAction('bell'); break;
        case '4': performAction('paper'); break;
      }
    } else if ((gameState === 'victory' || gameState === 'gameover') && e.key === ' ') {
      nextLevel();
    }
  }, [gameState, startGame, performAction, nextLevel]);

  const handleKeyUp = useCallback((e: KeyboardEvent) => {
    setKeys(prev => ({ ...prev, [e.key]: false }));
  }, []);

  return {
    gameState,
    currentDifficulty,
    gameTime,
    maxGameTime,
    confusionMeter,
    stealthMeter,
    animFrame,
    keys,
    setKeys,
    gameActions,
    student,
    teacher,
    backgroundStudents,
    particles,
    floatingTexts,
    startGame,
    nextLevel,
    performAction,
    handleKeyDown,
    handleKeyUp
  };
}
