import { useEffect } from 'react';
import { useLocation } from 'wouter';

export default function Home() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    // Redirect to the main game since this is a single-purpose game application
    setLocation('/');
  }, [setLocation]);

  return (
    <div className="font-pixel min-h-screen flex items-center justify-center" style={{
      background: 'linear-gradient(45deg, var(--deep-purple), var(--mid-purple))'
    }}>
      <div className="text-center">
        <div className="text-2xl text-neon-green mb-4 animate-pulse">
          CLASS TIME HACKER
        </div>
        <div className="text-sm text-white animate-blink">
          Loading...
        </div>
      </div>
    </div>
  );
}
