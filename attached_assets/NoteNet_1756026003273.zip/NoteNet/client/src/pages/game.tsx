import { useEffect } from 'react';
import GameCanvas from '@/components/GameCanvas';
import GameUI from '@/components/GameUI';
import MobileControls from '@/components/MobileControls';
import { useGameState } from '@/hooks/useGameState';

export default function Game() {
  const {
    gameState,
    gameTime,
    maxGameTime,
    confusionMeter,
    stealthMeter,
    currentDifficulty,
    gameActions,
    startGame,
    nextLevel,
    performAction,
    handleKeyDown,
    handleKeyUp,
  } = useGameState();

  useEffect(() => {
    const handleKeyDownEvent = (e: KeyboardEvent) => {
      handleKeyDown(e);
      e.preventDefault();
    };

    const handleKeyUpEvent = (e: KeyboardEvent) => {
      handleKeyUp(e);
    };

    const handleTouchStart = (e: TouchEvent) => {
      if (gameState === 'title') {
        startGame();
      }
      e.preventDefault();
    };

    document.addEventListener('keydown', handleKeyDownEvent);
    document.addEventListener('keyup', handleKeyUpEvent);
    document.addEventListener('touchstart', handleTouchStart);

    return () => {
      document.removeEventListener('keydown', handleKeyDownEvent);
      document.removeEventListener('keyup', handleKeyUpEvent);
      document.removeEventListener('touchstart', handleTouchStart);
    };
  }, [gameState, handleKeyDown, handleKeyUp, startGame]);

  const difficultyNames = ['Rookie', 'Veteran', 'Substitute', 'Principal'];

  return (
    <div className="font-pixel">
      <div 
        id="gameContainer" 
        className="flex justify-center items-center min-h-screen p-2"
        data-testid="game-container"
      >
        <GameCanvas />
        
        {/* Title Screen */}
        {gameState === 'title' && (
          <div 
            className="title-screen absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center"
            data-testid="title-screen"
          >
            <div className="text-xl md:text-2xl mb-5">CLASS TIME HACKER</div>
            <div className="start-prompt text-sm">Press SPACE or TAP to Start</div>
          </div>
        )}

        {/* Game UI */}
        {gameState === 'playing' && (
          <GameUI
            gameTime={Math.max(0, Math.ceil(maxGameTime - gameTime))}
            stealthMeter={Math.max(0, Math.ceil(stealthMeter))}
            confusionMeter={Math.min(100, Math.ceil(confusionMeter))}
            difficulty={difficultyNames[currentDifficulty]}
          />
        )}

        {/* Mobile Controls */}
        {gameState === 'playing' && (
          <MobileControls
            gameActions={gameActions}
            onPerformAction={performAction}
          />
        )}

        {/* Game Over Screen */}
        {(gameState === 'victory' || gameState === 'gameover') && (
          <div 
            className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center"
            data-testid="game-over-screen"
          >
            <div className="text-xl text-neon-green mb-4">
              {gameState === 'victory' ? 'MISSION COMPLETE!' : 'GAME OVER!'}
            </div>
            <div className="text-sm text-white mb-4">
              {gameState === 'victory' 
                ? 'You successfully confused the teacher!'
                : 'Better luck next time!'
              }
            </div>
            <div 
              className="text-xs text-neon-green start-prompt cursor-pointer"
              onClick={nextLevel}
              data-testid="button-continue"
            >
              Press SPACE to Continue
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
