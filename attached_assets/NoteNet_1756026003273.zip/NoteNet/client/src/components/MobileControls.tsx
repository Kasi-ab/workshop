import { useIsMobile } from '@/hooks/use-mobile';
import { useGameState } from '@/hooks/useGameState';

interface MobileControlsProps {
  gameActions: any;
  onPerformAction: (action: string) => void;
}

export default function MobileControls({ gameActions, onPerformAction }: MobileControlsProps) {
  const isMobile = useIsMobile();
  const { keys, setKeys } = useGameState();

  if (!isMobile) return null;

  const handleDPadPress = (key: string, pressed: boolean) => {
    setKeys(prev => ({ ...prev, [key]: pressed }));
  };

  const handleActionPress = (action: string) => {
    if (gameActions[action].cooldown <= 0) {
      onPerformAction(action);
    }
  };

  return (
    <div 
      className="absolute bottom-5 w-full flex justify-between px-5 z-10"
      data-testid="mobile-controls"
    >
      {/* Virtual D-pad */}
      <div className="grid grid-cols-3 grid-rows-3 gap-0.5 w-36 h-36">
        <div></div>
        <button 
          className="dpad-btn text-lg flex items-center justify-center"
          onTouchStart={() => handleDPadPress('ArrowUp', true)}
          onTouchEnd={() => handleDPadPress('ArrowUp', false)}
          data-testid="button-up"
        >
          ↑
        </button>
        <div></div>
        <button 
          className="dpad-btn text-lg flex items-center justify-center"
          onTouchStart={() => handleDPadPress('ArrowLeft', true)}
          onTouchEnd={() => handleDPadPress('ArrowLeft', false)}
          data-testid="button-left"
        >
          ←
        </button>
        <div></div>
        <button 
          className="dpad-btn text-lg flex items-center justify-center"
          onTouchStart={() => handleDPadPress('ArrowRight', true)}
          onTouchEnd={() => handleDPadPress('ArrowRight', false)}
          data-testid="button-right"
        >
          →
        </button>
        <div></div>
        <button 
          className="dpad-btn text-lg flex items-center justify-center"
          onTouchStart={() => handleDPadPress('ArrowDown', true)}
          onTouchEnd={() => handleDPadPress('ArrowDown', false)}
          data-testid="button-down"
        >
          ↓
        </button>
        <div></div>
      </div>
      
      {/* Action buttons */}
      <div className="flex flex-col gap-2">
        <button 
          className={`action-btn w-15 h-15 text-xs text-center ${gameActions.clock.cooldown > 0 ? 'cooldown' : ''}`}
          onTouchStart={() => handleActionPress('clock')}
          data-testid="button-clock"
        >
          CLOCK<br />HACK
        </button>
        <button 
          className={`action-btn w-15 h-15 text-xs text-center ${gameActions.chalk.cooldown > 0 ? 'cooldown' : ''}`}
          onTouchStart={() => handleActionPress('chalk')}
          data-testid="button-chalk"
        >
          CHALK<br />DROP
        </button>
        <button 
          className={`action-btn w-15 h-15 text-xs text-center ${gameActions.bell.cooldown > 0 ? 'cooldown' : ''}`}
          onTouchStart={() => handleActionPress('bell')}
          data-testid="button-bell"
        >
          FAKE<br />BELL
        </button>
        <button 
          className={`action-btn w-15 h-15 text-xs text-center ${gameActions.paper.cooldown > 0 ? 'cooldown' : ''}`}
          onTouchStart={() => handleActionPress('paper')}
          data-testid="button-paper"
        >
          PAPER<br />PLANE
        </button>
      </div>
    </div>
  );
}
