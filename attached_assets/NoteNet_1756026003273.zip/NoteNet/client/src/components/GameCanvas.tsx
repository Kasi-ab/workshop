import { useEffect, useRef } from 'react';
import { useGameState } from '@/hooks/useGameState';
import { drawStudent, drawTeacher, drawBackgroundStudent } from '@/utils/sprites';

export default function GameCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { 
    gameState, 
    student, 
    teacher, 
    backgroundStudents, 
    particles, 
    floatingTexts, 
    confusionMeter,
    animFrame 
  } = useGameState();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;

    const render = () => {
      // Clear canvas
      ctx.fillStyle = '#001122';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      
      if (gameState === 'playing') {
        // Render classroom background
        renderClassroom(ctx, canvas, confusionMeter);
        
        // Render background students
        backgroundStudents.forEach(bgStudent => {
          drawBackgroundStudent(ctx, bgStudent.x, bgStudent.y, bgStudent.type, animFrame);
        });
        
        // Render teacher
        drawTeacher(ctx, teacher.x, teacher.y, animFrame, teacher.emotion, teacher.direction);
        
        // Render student
        drawStudent(ctx, student.x, student.y, student.frame, student.direction, student.isHiding);
        
        // Render particles
        renderParticles(ctx, particles);
        
        // Render floating texts
        renderFloatingTexts(ctx, floatingTexts);
      }

      animationId = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animationId) {
        cancelAnimationFrame(animationId);
      }
    };
  }, [gameState, student, teacher, backgroundStudents, particles, floatingTexts, confusionMeter, animFrame]);

  return (
    <canvas
      ref={canvasRef}
      width={800}
      height={600}
      className="game-canvas max-w-full max-h-full"
      data-testid="game-canvas"
    />
  );
}

function renderClassroom(ctx: CanvasRenderingContext2D, canvas: HTMLCanvasElement, confusionMeter: number) {
  // Floor
  ctx.fillStyle = '#8B7355';
  ctx.fillRect(0, 500, 800, 100);
  
  // Walls
  ctx.fillStyle = '#F5DEB3';
  ctx.fillRect(0, 0, 800, 500);
  
  // Blackboard
  ctx.fillStyle = '#2F4F2F';
  ctx.fillRect(50, 50, 300, 150);
  ctx.strokeStyle = '#8B7355';
  ctx.lineWidth = 4;
  ctx.strokeRect(50, 50, 300, 150);
  
  // Blackboard text (changes based on confusion)
  ctx.fillStyle = '#FFF';
  ctx.font = '12px "Press Start 2P"';
  if (confusionMeter > 80) {
    ctx.fillText('2 + 2 = BANANA', 60, 80);
    ctx.fillText('Time = Chaos', 60, 100);
    ctx.fillText('Math = Illegal', 60, 120);
  } else if (confusionMeter > 50) {
    ctx.fillText('Today: ????day', 60, 80);
    ctx.fillText('Time: ERROR', 60, 100);
  } else {
    ctx.fillText('Today: Monday', 60, 80);
    ctx.fillText('Math Assignment', 60, 100);
  }
  
  // Clock on wall
  const clockX = 650;
  const clockY = 80;
  ctx.fillStyle = '#FFF';
  ctx.beginPath();
  ctx.arc(clockX, clockY, 40, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#000';
  ctx.lineWidth = 3;
  ctx.stroke();
  
  // Clock face and hands (glitches during high confusion)
  ctx.fillStyle = '#000';
  ctx.font = '12px "Press Start 2P"';
  if (confusionMeter > 70) {
    ctx.fillText('25:99', clockX - 20, clockY + 4);
  } else {
    ctx.fillText('2:15', clockX - 20, clockY + 4);
  }
  
  // Desks
  for (let i = 0; i < 6; i++) {
    const deskX = 150 + (i % 3) * 120;
    const deskY = 250 + Math.floor(i / 3) * 100;
    ctx.fillStyle = '#8B4513';
    ctx.fillRect(deskX, deskY, 80, 60);
    ctx.fillStyle = '#654321';
    ctx.fillRect(deskX, deskY, 80, 10);
  }
  
  // Intercom (for fake bell)
  ctx.fillStyle = '#C0C0C0';
  ctx.fillRect(400, 30, 60, 30);
  ctx.fillStyle = '#000';
  ctx.fillRect(405, 35, 10, 10);
  ctx.fillRect(415, 35, 10, 10);
  ctx.fillRect(425, 35, 10, 10);
}

function renderParticles(ctx: CanvasRenderingContext2D, particles: any[]) {
  particles.forEach(particle => {
    ctx.fillStyle = particle.color || '#FFFFFF';
    ctx.fillRect(particle.x, particle.y, particle.size || 2, particle.size || 2);
  });
}

function renderFloatingTexts(ctx: CanvasRenderingContext2D, floatingTexts: any[]) {
  ctx.font = '12px "Press Start 2P"';
  floatingTexts.forEach(text => {
    ctx.fillStyle = text.color;
    ctx.fillText(text.text, text.x, text.y);
  });
}
