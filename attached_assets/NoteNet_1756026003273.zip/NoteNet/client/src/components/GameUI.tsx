interface GameUIProps {
  gameTime: number;
  stealthMeter: number;
  confusionMeter: number;
  difficulty: string;
}

export default function GameUI({ gameTime, stealthMeter, confusionMeter, difficulty }: GameUIProps) {
  return (
    <div 
      className="ui-overlay absolute top-4 left-4 text-xs"
      data-testid="game-ui"
    >
      <div>Time: <span data-testid="text-time">{gameTime}</span>s</div>
      <div>Stealth: <span data-testid="text-stealth">{stealthMeter}</span>%</div>
      <div>Confusion: <span data-testid="text-confusion">{confusionMeter}</span>%</div>
      <div>Level: <span data-testid="text-difficulty">{difficulty}</span></div>
    </div>
  );
}
